const express = require('express');
const path = require('path');

const app = express();
const port = process.env.PORT || 8080;
const DIST_DIR = path.join(__dirname, 'dist');
app.use(express.static(DIST_DIR));

app.get('/', function(req, res) {
  res.sendFile(path.join(DIST_DIR, 'index.html'));
});

app.listen(port);
console.log('Server started at http://localhost:' + port);